package kr.co.amnet;

import java.io.Closeable;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;

public class AMNet extends Listener implements Closeable {
	
	private final static String DATA_DIR = "data";
	private final static String CONFIG_FILE = "config";
	private final static String MD5_ROOT = "63a9f0ea7bb98050796b649e85481845";
	public static long expire = 0;
	
	private final Syslog server;
	
	private final File root;
	
	public AMNet() throws Exception {
		super(2014);
		
		root = new File(this.getClass().getProtectionDomain().getCodeSource().getLocation().toURI()).getParentFile();
		
		System.out.format("Directory : %s\n", root.getAbsoluteFile());
		
		File dataRoot = new File(root, DATA_DIR);
		
		dataRoot.mkdir();
		
		File confFile = new File(root, CONFIG_FILE);
		
		if (!confFile.isFile()) {
			try (FileOutputStream fos = new FileOutputStream(confFile)) {
				fos.write(new JSONObject()
					.put("list", new JSONObject())
					.put("password", MD5_ROOT)
					.toString().getBytes(StandardCharsets.UTF_8));
			}
		}
		
		server = new Syslog(dataRoot);
	}
		
	public static JSONObject getJSONFromFile(File file) throws IOException {
		try {
			return new JSONObject(new String(Files.readAllBytes(file.toPath()), StandardCharsets.UTF_8));
		}
		catch (JSONException jsone) {
			return null;
		}
	}
	
	private Response parseRequest(Request request) throws IOException{
		if (!"HTTP/1.1".equals(request.getRequestVersion())) {
			return Response.getInstance(Response.Status.VERSIONNOTSUP);
		}
		
		switch(request.getRequestMethod()) {
		case "OPTIONS":
			return Response.getInstance(Response.Status.OK).setResponseHeader("Allow", "GET, POST");
		
		case"POST":
			try {
				JSONObject data = new JSONObject(new String(request.getRequestBody(), StandardCharsets.UTF_8.name()));
				
				if (!data.has("command")) {
					return Response.getInstance(Response.Status.BADREQUEST
						, new JSONObject().put("error", "command not found").toString());
				}
				
				return executeRequest(request, data);
			} catch (JSONException e) {e.printStackTrace();
				return Response.getInstance(Response.Status.BADREQUEST
					, new JSONObject().put("error", "invalid json request").toString());
			} catch (UnsupportedEncodingException e) {
				return Response.getInstance(Response.Status.BADREQUEST
					, new JSONObject().put("error", "UTF-8 encoding required").toString());
			} catch (Exception e) {
				return Response.getInstance(Response.Status.SERVERERROR);
			}
		}
		
		return Response.getInstance(Response.Status.NOTALLOWED).setResponseHeader("Allow", "OPTIONS, POST, GET");
	}
	
	public Response executeRequest(Request request, JSONObject data) throws IOException {
		String cmd = data.getString("command");
		Session session = getSession(request);
		
		if ("signin".equals(cmd)) {
			if (session == null) {
				try {
					if (getPassword().equals(data.getString("password"))) {
						session = Session.getInstance(0);
					}
				} catch (JSONException jsone) {
					return Response.getInstance(Response.Status.BADREQUEST
						, new JSONObject().put("error", "invalid json request").toString());
				}
			}
			
			if (session == null) {
				return Response.getInstance(Response.Status.UNAUTHORIZED);
			}
			
			return Response.getInstance(Response.Status.OK,
				new JSONObject().put("level", (int)session.getExtras()).toString())
				.setResponseHeader("Set-Cookie", String.format("SESSION=%s; HttpOnly", session.getCookie()));
		}
		else if ("signout".equals(cmd)) {
			if (session != null) {
				session.close();
			}
			
			return Response.getInstance(Response.Status.OK);
		}
		
		if (session == null) {
			return Response.getInstance(Response.Status.UNAUTHORIZED);
		}
		
		switch(cmd) {
		case "host":
			return Response.getInstance(Response.Status.OK
					, this.server.getHost(data.getLong("date")));
		
		case "log":
			return Response.getInstance(Response.Status.OK
					, this.server.getLog(data.getString("ip"), data.getLong("date")));
		
		case "config":
			return Response.getInstance(Response.Status.OK, getConfig().toString());
		
		case "list":
			return Response.getInstance(Response.Status.OK, modifyList(data));
			
		case "summary":
			return Response.getInstance(Response.Status.OK,
				this.server.summarize(data.getLong("start"), data.getLong("end")));
			
		case "password":
			if (getPassword().equals(data.getString("password"))) {
				setPassword(data.getString("password2"));
				
				return Response.getInstance(Response.Status.OK);
			}
			else {
				return Response.getInstance(Response.Status.UNAUTHORIZED);
			}
		}
		
		return Response.getInstance(Response.Status.BADREQUEST);
	}
	
	private byte [] modifyList(JSONObject data) throws IOException {
		File file = new File(root, CONFIG_FILE);
		JSONObject
			config = getJSONFromFile(file),
			list = config.getJSONObject("list");
		String ip = data.getString("ip");
		
		if (data.isNull("device")) {
			list.remove(ip);
		}
		else {
			list.put(ip, data.getJSONObject("device"));
		}
		
		try (FileOutputStream fos = new FileOutputStream(file)) {
			fos.write(config.toString().getBytes(StandardCharsets.UTF_8));
		}
		
		return list.toString().getBytes(StandardCharsets.UTF_8);
	}
	
	private static Session getSession(Request request) {
		String cookie = request.getRequestHeader(Request.Header.COOKIE);
		
		if (cookie == null) {
			return null;
		}
		
		String [] cookies = cookie.split("; ");
		String [] token;
		Session session = null;
		
		for(int i=0, length=cookies.length; i<length; i++) {
			token = cookies[i].split("=");
			
			if (token.length == 2 && "SESSION".equals(token[0])) {
				session = Session.find(token[1]);
				
				if (session != null) {
					session.update();
				}
			}
		}
		
		return session;
	}
	
	private String getPassword() throws IOException {
		JSONObject config = getJSONFromFile(new File(root, CONFIG_FILE));
		
		return config.has("password")? config.getString("password"): MD5_ROOT;
	}
	
	private JSONObject getConfig() throws IOException {
		JSONObject config = getJSONFromFile(new File(root, CONFIG_FILE));
		
		config.remove("password");
		
		return config;
	}
	
	private void setPassword(String password) throws IOException {
		File file = new File(root, CONFIG_FILE);
		JSONObject config = getJSONFromFile(file);
		
		config.put("password", password);
		
		try (FileOutputStream fos = new FileOutputStream(file)) {
			fos.write(config.toString().getBytes(StandardCharsets.UTF_8));
		}
	}
	
	@Override
	public void close() {
		try {			
			this.server.close();
			
			super.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	public static void main(String[] args) {
		try {
			final AMNet amnet = new AMNet();
			
			Runtime.getRuntime().addShutdownHook(
				new Thread() {
					public void run() {
						amnet.close();
					}
				});
		}
		catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Override
	protected void onStart() {
		System.out.println("HTTP Server start.");
	}

	@Override
	protected void onRequest(Request request) throws IOException {
		String origin = request.getRequestHeader(Request.Header.ORIGIN);
		Response response = parseRequest(request);
		
		if (origin != null) {
			response.setResponseHeader("Access-Control-Allow-Origin", origin);
			response.setResponseHeader("Access-Control-Allow-Credentials", "true");	
		}
		
		request.sendResponse(response);
	}

	@Override
	protected void onClose(Request request) {
	}

	@Override
	protected void onException(Exception e) {
	}
	
}
